<template>
    <div class="Newslist">
      <ul class="mui-table-view">
				<li class="mui-table-view-cell mui-media" v-for="item of list" :key="item.id">
					<router-link :to="'/NewsInfo?nid='+item.id">
						<img class="mui-media-object mui-pull-left" :src="item.img_url">
						<div class="mui-media-body">
							{{item.title}}
							<p class='mui-ellipsis'>
                            <span>{{item.ctime |datatimerFilter}}
                            </span>
                            <span>点击{{item.point}}</span>
                            </p>
						</div>
					</router-link>
				</li>
			</ul>
         <mt-button type="primary" size="large" @click="getMore">加载更多</mt-button>   
    </div>
</template>
<script>
    export default{
        data(){
            return{
               list:[],
               pno:1,
               pageSize:7
            }
        },
        methods:{
            getMore(){
                this.pno++;
                var url="http://127.0.0.1:3001/index";
                url+="/newslist?pno="+this.pno;
                url+="&pageSize="+this.pageSize;
                this.axios.get(url).then(result=>{
                    var rows=this.list.concat(result.data.data);
                    this.list=rows;
                })
            },
           getNewslist(){
               var url="http://127.0.0.1:3001/index/newslist";
               this.axios.get(url).then(result=>{
                   this.list=result.data.data;
                   //console.log(this.list)
               })
           }
        },
        created() {
            //console.log(this.$route.query.nid)
            this.getNewslist();
        },
    }
</script>
<style>
    .Newslist li .mui-ellipsis{
        display:flex;
        justify-content:space-between;
        font-size:12px;
        color:#226aff;
    }
</style>
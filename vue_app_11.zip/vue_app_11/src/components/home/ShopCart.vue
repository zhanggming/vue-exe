<template>
    <div class="shopcart">
      <div class="mui-card">
				<div class="mui-card-header">
				<h3>购物车列表</h3>
				<h4>全选&nbsp;<input type="checkbox" :checked="allcb" @click="setAll"></h4>
				</div>
				<div class="mui-card-content">
					<div class="mui-card-content-inner">
                 <ul class="mui-table-view">
				<li class="mui-table-view-cell mui-media" v-for="(item,i) in list" :key="item.id">
					<a javasript=";">
						<img class="mui-media-object mui-pull-left" :src="'http://127.0.0.1:3001/'+item.img_url">
						<div class="mui-media-body">
							{{item.title}}
							<p class='mui-ellipsis'>
                            <span>￥{{item.price}}
                            </span>
                            <span><button @click="delItem" :data-id="item.id" :data-idx="i">删除</button></span>
                            </p>
						</div>
					</a><br>
                    <input type="checkbox" :checked="item.cb" :data-i="i" @click="modifyItem"/>
				</li>
			</ul>
            
				</div>
				</div>
				<div class="mui-card-footer"><button @click="removeItem">删除所选的商品</button>小计：￥3.00</div>
			</div>
         
    </div>
</template>
<script>
    import {Toast} from 'mint-ui'
    export default{
        data(){
            return{
                list:[],
                cb:false,
                allcb:false    
            }
        },
        methods:{
            delItem(e){
              var id=e.target.dataset.id;
              var idx=e.target.dataset.idx;
             // console.log(idx)
             var url="http://127.0.0.1:3001/index/";
             url+="delCartItem?id="+id;
             //发送请求
             this.axios.get(url).then(result=>{
                 if(result.data.code==1){
                     Toast("删除成功")
                     this.list.splice(idx,1);
                 }
             })
            },
            loadMore(){
                //创建变量
                var url="http://127.0.0.1:3001/index/";
                url+="cartlist?uid=1";
                //发送ajax请求
                this.axios.get(url).then(result=>{
                    //console.log(result.data)
                    var rows=result.data.data;
                    //购物车数量
                    this.$store.commit("updateCount",rows.length)
                    for(var item of rows){
                        item.cb=false;
                    }
                    this.list=rows;
                    //console.log(this.list)
                })
               
            },
            setAll(e){
                    var cb=e.target.checked;
                    //console.log(cb)
                    this.allcb=cb;
                    for(var item of this.list){
                     item.cb=cb;
                    }
                },
            modifyItem(e){
                var idx=e.target.dataset.i;
                //console.log(idx)
                var checked=e.target.checked;
                this.list[idx].cb=checked;
                //
                var count=0;
                for(var item of this.list){
                    if(item.cb){
                        if(item.cb){
                            count++;
                        }
                    }
                    if(count==this.list.length){
                        this.allcb=true;
                    }else{
                        this.allcb=false;
                    }
                }
            },
            removeItem(){
                var html="";
                for(var item of this.list){
                    if(item.cb){
                        html+=item.id+",";
                    }
                } 
               html=html.substring(0,html.length-1)
              // console.log(html)
               var url="http://127.0.0.1:3001/index/";
               url+="removeMItem?ids="+html;
               this.axios.get(url).then
               (result=>{
                   if(result.data.code==1){
                       Toast("删除成功");
                       this.loadMore();
                   }
               })
            }    
        },
        created() {
            this.loadMore();
        },
    }
</script>
<style>
     .shopcart li .mui-ellipsis{
        display:flex;
        justify-content:space-between;
        font-size:12px;
        color:#226aff;
    }
</style>
<template>
   <div classs="app-newsinfo">
      <div class="mui-card">
				<div class="mui-card-header mui-card-media" :style="'height:40vw;background-image:url('+info.img_url+')' "></div>
				<div class="mui-card-content">
					<div class="mui-card-content-inner">
						<p>Posted on {{info.ctime|dateFilter}}</p>
						<p style="color: #333;">{{info.content}}</p>
					</div>
				</div>
				<div class="mui-card-footer">
					<a class="mui-card-link">Like</a>
					<a class="mui-card-link">Read more</a>
				</div>
			</div>
            <comment-box></comment-box>
   </div>
</template>
<script>
 //引入
 import comment from "../sub/comment.vue"
 //调用
    export default{
        data(){
            return{
                info:{}
            }
        },
        created() {
            this.findNewsinfo();
        },
        methods:{
            findNewsinfo(){
                //获取参数
                var nid=this.$route.query.nid;
                //发送axios请求
                var url="http://127.0.0.1:3001/index/";
                url+="findNewsInfo?id="+nid;
                this.axios.get(url).then(result=>{
                    this.info=result.data.data[0];
                })
            }
        },
       components:{
            "comment-box":comment
        }
    }
</script>
<style>
    
</style>
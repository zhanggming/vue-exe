<template>
    <div class="app-swiper">
        <mt-swipe :auto="3000">
           <mt-swipe-item v-for="item in list" :key="item.id">
           <img :src="'http://127.0.0.1:3001/'+item.img">
           </mt-swipe-item>
        </mt-swipe>
    </div>
</template>
<script>
export default{
    data(){
        return{}
    },
    props:["list"]
    }
</script>
<style>
    .app-swiper .mint-swipe{
        height:200px;
    }
    .app-swiper .mint-swipe img{
        width:100%;
    }
</style>
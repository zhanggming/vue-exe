SET NAMES UTF8;
DROP DATABASE IF EXISTS bsk;
CREATE DATABASE bsk CHARSET=UTF8;
USE bsk;
/*首页轮播图片*/
CREATE TABLE bsk_imges(
   id INT PRIMARY KEY AUTO_INCREMENT,
   img VARCHAR(128)
);
INSERT INTO bsk_imges VALUES
(NULL,'./img/index/banner1.jpg'),
(NULL,'./img/index/banner2.jpg'),
(NULL,'./img/index/banner3.jpg'),
(NULL,'./img/index/banner4.jpg');
/*健康时讯*/
CREATE TABLE bsk_news(
   id INT PRIMARY KEY AUTO_INCREMENT,
   title VARCHAR(255),
   img_url VARCHAR(255),
   ctime DATETIME,
   point INT,
   content VARCHAR(2000)
);
INSERT INTO bsk_news VALUES
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'123'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'124'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'125'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'126'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'127'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'128'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'129'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'12a'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'12b'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'12c'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'12d'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'12e'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'12f'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'12g'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'12h'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'12i'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'12j'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'12k'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'12l'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'12m'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'12n'),
(NULL,'123','http://127.0.0.1:3001/img/index/2.png',now(),0,'12o');
/*创建评论列表*/
CREATE TABLE bsk_comment(
    id INT PRIMARY KEY AUTO_INCREMENT,
    content VARCHAR(50),
    ctime DATETIME,
    nid INT
);
INSERT INTO bsk_comment VALUES(null,'赞一个1',now(),5);
INSERT INTO bsk_comment VALUES(null,'赞一个2',now(),5);
INSERT INTO bsk_comment VALUES(null,'赞一个3',now(),5);
INSERT INTO bsk_comment VALUES(null,'赞一个4',now(),5);
INSERT INTO bsk_comment VALUES(null,'赞一个5',now(),5);
INSERT INTO bsk_comment VALUES(null,'赞一个6',now(),5);
INSERT INTO bsk_comment VALUES(null,'赞一个7',now(),5);
INSERT INTO bsk_comment VALUES(null,'赞一个8',now(),5);
INSERT INTO bsk_comment VALUES(null,'赞一个9',now(),5);
INSERT INTO bsk_comment VALUES(null,'赞一个10',now(),5);
INSERT INTO bsk_comment VALUES(null,'赞一个11',now(),5);
/*商品列表*/
CREATE TABLE bsk_products(
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(64),
    price DECIMAL(7,2),
    img_url VARCHAR(128),
    content INT
);
INSERT INTO bsk_products VALUES
(NULL,'极地牛乳',218.00,'./img/products/1.png',1089),
(NULL,'情定爱情海',218.00,'./img/products/2.png',413412),
(NULL,'白色红丝绒',218.00,'./img/products/3.png',163055),
(NULL,'奥利奥雪域牛乳芝士',218.00,'./img/products/4.png',327981),
(NULL,'冰烤燃情芝士',218.00,'./img/products/5.png',313871),
(NULL,'莱茵河苺妖精',218.00,'./img/products/6.png',285697),
(NULL,'双果小确幸',288.00,'./img/products/7.png',11549),
(NULL,'芒GO',188.00,'./img/products/8.png',9569),
(NULL,'歌剧魅影',218.00,'./img/products/9.png',25461),
(NULL,'红莓森林(3.8特供)',218.00,'./img/products/10.png',10541),
(NULL,'酸奶芝士',218.00,'./img/products/11.png',6908),
(NULL,'轨迹',188.00,'./img/products/12.png',7150),
(NULL,'布朗尼精灵',218.00,'./img/products/13.png',1089),
(NULL,'PAPI熊蛋糕',218.00,'./img/products/14.png',18653),
(NULL,'金色榴莲',218.00,'./img/products/15.png',1009),
(NULL,'茶色生香',218.00,'./img/products/16.png',263),
(NULL,'情定爱情海',218.00,'./img/products/17.png',1089),
(NULL,'新狮子王',218.00,'./img/products/18.png',140811),
(NULL,'松露巧克力',218.00,'./img/products/19.png',89732),
(NULL,'情定爱情海',218.00,'./img/products/20.png',547564);
/*创建用户登录列表*/
CREATE TABLE bsk_login(
    id INT PRIMARY KEY AUTO_INCREMENT,
    uname VARCHAR(25),
    upwd VARCHAR(32)
);
INSERT INTO bsk_login VALUES(NULL,'tom',md5('123')),
(NULL,'jerry',md5('123')),
(NULL,'mingming',md5('123')),
(NULL,'dingding',md5('123')),
(NULL,'dangdang',md5('123'));
/*购物车列表*/
CREATE TABLE bsk_cart(
    id INT PRIMARY KEY AUTO_INCREMENT,
    count INT,
    price DECIMAL(15,2),
    pid INT,
    uid INT
);
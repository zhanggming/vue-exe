//1.加载模块
const express=require("express");
const index=require("./routes/index");
const bodyParser=require("body-parser");
//2.创建服务器对象
var app=express();
//监听3000端口
app.listen(3001);
app.use(bodyParser.urlencoded({extended:false}));
//4.指定静态目录
app.use(express.static("public"))
//5.加载跨域访问模块
const cors=require("cors");
app.use(cors({
    origin:["http://127.0.0.1:8081","http://localhost:8081"],
    credentials:true
}));
//引入模块
const session=require("express-session");
//配置
app.use(session({
  secret:"128位随机字符",//安全字符串
  resave:false,//每次请求是否更新数据
  saveUninitialized:true,//初始化时保存数据
  cookie:{
    maxAge:1000*60*60*8
  }
}));
//路由器管理路由
app.use("/index",index)